from flask import Flask, request, jsonify
import os
import psycopg2
from psycopg2.extras import RealDictCursor

app = Flask(__name__)

DATABASE_URL = os.getenv("DATABASE_URL")

def get_db_connection():
    conn = psycopg2.connect(DATABASE_URL, sslmode='require')
    return conn

@app.route("/")
def index():
    return jsonify({"message": "LogisTille WMS is running on Render!"})

@app.route("/api/receipts", methods=["POST"])
def add_receipt():
    data = request.get_json()
    sku = data.get("sku")
    qty = data.get("qty")
    batch_code = data.get("batch_code")
    location_code = data.get("location_code")

    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute(
        "INSERT INTO stock (sku, qty, batch_code, location_code) VALUES (%s, %s, %s, %s)",
        (sku, qty, batch_code, location_code)
    )
    conn.commit()
    cur.close()
    conn.close()
    return jsonify({"status": "success"}), 201

@app.route("/api/stock/<sku>", methods=["GET"])
def get_stock(sku):
    conn = get_db_connection()
    cur = conn.cursor(cursor_factory=RealDictCursor)
    cur.execute("SELECT * FROM stock WHERE sku = %s", (sku,))
    rows = cur.fetchall()
    cur.close()
    conn.close()
    return jsonify(rows)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)))
